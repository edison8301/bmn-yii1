<?php

/**
 * LoginForm class.
 * LoginForm is the data structure for keeping
 * user login form data. It is used by the 'login' action of 'SiteController'.
 */
class CetakQrForm extends CFormModel
{
	public $kode;
	public $nup_awal;
	public $nup_akhir;

	public function rules()
	{
		return array(
			array('kode', 'required','message'=>'{attribute} harus diisi'),
			array('nup_awal, nup_akhir', 'numerical', 'integerOnly'=>true,'message'=>'{attribute} harus berbentuk angka'),
			array('nup_awal, nup_akhir', 'required','message'=>'{attribute} harus diisi'),
		);
	}

	public function attributeLabels()
	{
		return array(
			'kode'=>'Kode',
			'nup_awal'=>'NUP Awal',
			'nup_akhir'=>'NUP Akhir',
		);
	}
}
