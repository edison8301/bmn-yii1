	<?php
/* @var $this BarangController */
/* @var $model Barang */

$this->breadcrumbs=array(
	'Barang'=>array('admin'),
	'Kelola Barang',
);


?>

<h1>Kelola Barang</h1>


<?php $this->widget('booster.widgets.TbGridView', array(
	'id'=>'barang-grid',
	'dataProvider'=>$model->search(),
	'type'=>'striped bordered condensed',
	'filter'=>$model,
    'enablePagination' => true,
    /*'rowCssClassExpression' => '"' . $this->getCssClass($model) . '"',*/
	'columns'=>array(
		array(
			'value' => '$data->kode',
			'name' => 'kode',
			'headerHtmlOptions' => array('width'=>'10%','style'=>'text-align:center'),
			'htmlOptions' => array('style'=>'text-align:center;'),
			'cssClassExpression' => '$data->getCssClass($data->id_barang_kondisi)',
		),
		array(
			'name'=>'nama',
			'headerHtmlOptions' => array('width' =>'25%','style'=>'text-align:center'),
			'cssClassExpression' => '$data->getCssClass($data->id_barang_kondisi)',
		),
		array(
			 'name' => 'nup',
			 'headerHtmlOptions' => array('width' =>'5%','style'=>'text-align:center'),
			 'htmlOptions'=>array('style'=>'text-align:center'),
			 'cssClassExpression' => '$data->getCssClass($data->id_barang_kondisi)',
		),
		array(
			'value' => 'Helper::getTanggalSingkat($data->tahun_perolehan)',
			'name' => 'tahun_perolehan',
			'headerHtmlOptions' => array('width' =>'5%','style'=>'text-align:center'),
			'htmlOptions' => array('style'=>'text-align:center'),
			'cssClassExpression' => '$data->getCssClass($data->id_barang_kondisi)',
		),
		array(
		 	'header' => 'Lokasi',
		 	'name' => 'id_lokasi',
		 	'value' => '$data->getLokasi()',
		 	'headerHtmlOptions' => array('width' =>'15%','style'=>'text-align:center'),
		 	'htmlOptions'=>array('style'=>'text-align:center'),
		 	'filter' => CHtml::listData(Lokasi::model()->findAll(array('order'=>'nama ASC')),'id','nama'),
		 	'cssClassExpression' => '$data->getCssClass($data->id_barang_kondisi)',
		),
		array(
		 	'header' => 'Kondisi',
		 	'name' => 'id_barang_kondisi',
		 	'value' => '$data->getBarangKondisi()',
		 	'headerHtmlOptions' => array('width' =>'10%','style'=>'text-align:center'),
		 	'htmlOptions'=>array('style'=>'text-align:center'),
		 	'filter' => CHtml::listData(BarangKondisi::model()->findAll(array('order'=>'nama ASC')),'id','nama'),
		 	'cssClassExpression' => '$data->getCssClass($data->id_barang_kondisi)',
		),
		array(
			 'name' => 'perawatan_terakhir',
			 'value'=>'Helper::getTanggalSingkat($data->perawatan_terakhir)',
			 'headerHtmlOptions' => array('width' =>'10%','style'=>'text-align:center'),
			 'htmlOptions'=>array('style'=>'text-align:center'),
			 'cssClassExpression' => '$data->getCssClass($data->id_barang_kondisi)',
		),
		array(
			 'name' => 'pemeriksaan_terakhir',
			 'value'=>'Helper::getTanggalSingkat($data->pemeriksaan_terakhir)',
			 'headerHtmlOptions' => array('width' =>'10%','style'=>'text-align:center'),
			 'htmlOptions'=>array('style'=>'text-align:center'),
			 'cssClassExpression' => '$data->getCssClass($data->id_barang_kondisi)',
		),
		array(
			'type'=>'raw',
			'value'=>'CHtml::link("<i class=\"glyphicon glyphicon-qrcode\"></i>",array("barang/cetakQr","id"=>"$data->id"),array("target" => "_blank","data-toggle"=>"tooltip","title"=>"Cetak QR"))',
			'htmlOptions'=>array('style'=>'text-align:center'),
			'cssClassExpression' => '$data->getCssClass($data->id_barang_kondisi)',

		),		
		array(
			'class'=>'booster.widgets.TbButtonColumn',
			'cssClassExpression' => '$data->getCssClass($data->id_barang_kondisi)',
			'htmlOptions' => array(
				'style' => 'width: 60px;text-align:center')
		),
	),
)); ?>



<div>&nbsp;</div>

<div class="well" style="text-align:right">
<?php $this->widget('booster.widgets.TbButton',array(
		'buttonType'=>'link',
		'label'=>'Tambah',
		'icon'=>'plus',
		'size'=>'small',
		'context'=>'danger',
		'url'=>('barang/create')
)); ?>&nbsp;
<?php $this->widget('booster.widgets.TbButton',array(
		'buttonType'=>'link',
		'label'=>'Ekspor ke Excel',
		'icon'=>'download',
		'context'=>'success',
		'size'=>'small',
		'url'=>array('barang/exportExcel')
)); ?>&nbsp;
<?php $this->widget('booster.widgets.TbButton',array(
		'buttonType'=>'link',
		'label'=>'Laporan Perawatan',
		'icon'=>'file',
		'context'=>'success',
		'size'=>'small',
		'url'=>array('barang/reportPerawatan')
)); ?>&nbsp;


</div>
